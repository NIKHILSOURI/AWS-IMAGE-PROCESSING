# lambda_function.py
import os
import json
import time
import base64
import urllib.parse
import io

import boto3
from PIL import Image

s3 = boto3.client("s3")
rek = boto3.client("rekognition")
cw = boto3.client("cloudwatch")

# You can also set these as environment variables in Lambda console later.
INPUT_BUCKET = os.environ.get("INPUT_BUCKET", "dv1566-image-input-nikhil")
OUTPUT_BUCKET = os.environ.get("OUTPUT_BUCKET", "dv1566-image-output-nikhil")

# ---------------------------
# Helper: send metrics
# ---------------------------
def put_metrics(success=True, processing_ms=None, labels_count=0, operation="labels"):
    metric_data = []

    if success:
        metric_data.append({
            "MetricName": "ProcessedImagesCount",
            "Value": 1,
            "Unit": "Count"
        })
    else:
        metric_data.append({
            "MetricName": "FailedImagesCount",
            "Value": 1,
            "Unit": "Count"
        })

    if processing_ms is not None:
        metric_data.append({
            "MetricName": "ProcessingTimeMs",
            "Value": processing_ms,
            "Unit": "Milliseconds"
        })

    metric_data.append({
        "MetricName": "LabelsCount",
        "Value": labels_count,
        "Unit": "Count"
    })

    # Optional: add a simple dimension for operation
    cw.put_metric_data(
        Namespace="DV1566/ImageProcessing",
        MetricData=[
            {
                **m,
                "Dimensions": [
                    {"Name": "Operation", "Value": operation}
                ]
            }
            for m in metric_data
        ]
    )

# ---------------------------
# Helper: run Rekognition
# ---------------------------
def run_rekognition(bucket, key):
    r = rek.detect_labels(
        Image={"S3Object": {"Bucket": bucket, "Name": key}},
        MaxLabels=10,
        MinConfidence=70.0
    )

    labels = r.get("Labels", [])
    labels_out = [
        {"Name": lab["Name"], "Confidence": lab["Confidence"]}
        for lab in labels
    ]
    return labels_out

# ---------------------------
# Helper: apply image operation (Pillow)
# ---------------------------
def apply_operation(image_bytes, operation, width=None, height=None):
    """
    image_bytes: original image bytes
    operation: "labels", "grayscale", "resize", "thumbnail"
    width/height: optional for resize/thumbnail
    """
    if operation == "labels":
        # No pixel change, just return original
        return image_bytes, "original"

    img = Image.open(io.BytesIO(image_bytes))

    if operation == "grayscale":
        img = img.convert("L")  # L = 8-bit pixels, black and white
    elif operation == "resize":
        if width is None or height is None:
            # fallback if user forgot to send width/height
            width, height = img.size
        img = img.resize((int(width), int(height)))
    elif operation == "thumbnail":
        if width is None or height is None:
            width, height = 256, 256
        img.thumbnail((int(width), int(height)))
    else:
        # Unknown operation -> keep original
        operation = "labels"  # treat as label-only
        return image_bytes, "original"

    buf = io.BytesIO()
    # Use PNG as a safe default
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf.read(), "processed"

# ---------------------------
# Core: process image from S3
# ---------------------------
def process_image_from_s3(bucket, key, operation="labels",
                          width=None, height=None,
                          run_rekognition_flag=True):
    """
    Downloads image from S3, applies operation, stores result in output bucket,
    optionally runs Rekognition, returns response dict.
    """
    t0 = time.time()

    # 1) Download original
    obj = s3.get_object(Bucket=bucket, Key=key)
    original_bytes = obj["Body"].read()

    # 2) Apply desired image operation
    processed_bytes, kind = apply_operation(original_bytes, operation, width, height)

    # 3) Store processed image in OUTPUT_BUCKET
    base_name = os.path.basename(key)

    if kind == "original":
        # no change -> still put under processed/original/ to keep structure
        out_key = f"processed/original/{base_name}"
    else:
        out_key = f"processed/{operation}/{base_name}"

    s3.put_object(
        Bucket=OUTPUT_BUCKET,
        Key=out_key,
        Body=processed_bytes,
        ContentType="image/png"
    )

    # 4) Optionally run Rekognition
    labels_out = []
    if run_rekognition_flag:
        # You can choose: run on original or on processed.
        # Here we run on processed, since that's what user sees.
        labels_out = run_rekognition(OUTPUT_BUCKET, out_key)

    t1_ms = (time.time() - t0) * 1000.0

    # 5) Metrics
    put_metrics(
        success=True,
        processing_ms=t1_ms,
        labels_count=len(labels_out),
        operation=operation
    )

    # 6) Also return processed image as base64 so UI can display directly
    processed_b64 = base64.b64encode(processed_bytes).decode("utf-8")

    result = {
        "source_bucket": bucket,
        "source_key": key,
        "operation": operation,
        "output_image_bucket": OUTPUT_BUCKET,
        "output_image_key": out_key,
        "processing_time_ms": t1_ms,
        "labels_count": len(labels_out),
        "labels": labels_out,
        "output_image_base64": processed_b64
    }
    return result

# ---------------------------
# Lambda handler
# ---------------------------
def lambda_handler(event, context):
    try:
        # 1) S3 trigger path (unchanged logic, but now we support operations too if needed later)
        if "Records" in event and event["Records"][0].get("eventSource") == "aws:s3":
            rec = event["Records"][0]
            b = rec["s3"]["bucket"]["name"]
            raw_key = rec["s3"]["object"]["key"]
            k = urllib.parse.unquote_plus(raw_key)

            # For S3 events we keep default behaviour: labels only
            res = process_image_from_s3(
                bucket=b,
                key=k,
                operation="labels",
                width=None,
                height=None,
                run_rekognition_flag=True
            )

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "message": "processed_from_s3",
                    **res
                })
            }

        # 2) HTTP API path
        body = event.get("body")
        if body is None:
            raise ValueError("Missing body in HTTP event")

        if event.get("isBase64Encoded"):
            body = base64.b64decode(body).decode("utf-8")

        data = json.loads(body)

        # Read operation parameters
        operation = data.get("operation", "labels")
        run_rekognition_flag = bool(data.get("runRekognition", True))
        width = data.get("width")
        height = data.get("height")

        # If width/height come as strings from JSON, they are fine; we cast later.

        # Two modes:
        # A) Old mode: client sends bucket + key
        # B) New mode: client sends imageBase64 (we store it to S3 ourselves)
        if "imageBase64" in data:
            # New mode: UI sends us an image directly
            img_b64 = data["imageBase64"]
            img_bytes = base64.b64decode(img_b64)

            # Store original image into INPUT_BUCKET with a generated name
            key = f"uploads/{int(time.time() * 1000)}.png"
            s3.put_object(
                Bucket=INPUT_BUCKET,
                Key=key,
                Body=img_bytes,
                ContentType="image/png"
            )
            source_bucket = INPUT_BUCKET
        else:
            # Old mode: use provided bucket + key
            source_bucket = data["bucket"]
            key = data["key"]

        res = process_image_from_s3(
            bucket=source_bucket,
            key=key,
            operation=operation,
            width=width,
            height=height,
            run_rekognition_flag=run_rekognition_flag
        )

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                # Allow simple CORS so the browser UI can call this
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "message": "processed_from_http",
                **res
            })
        }

    except Exception as e:
        # Send failure metric
        try:
            put_metrics(success=False, processing_ms=None,
                        labels_count=0, operation="error")
        except Exception:
            # avoid failing again due to CloudWatch issues
            pass

        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"error": str(e)})
        }
